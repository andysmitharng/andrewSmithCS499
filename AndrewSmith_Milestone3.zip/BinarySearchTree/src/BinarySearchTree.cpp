//============================================================================
// Name        : BinarySearchTree.cpp
// Author      : Andrew Smith
// Version     : 1.0
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <time.h>
#include <algorithm>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations
double strToDouble(string str, char ch);
string bidDept;

// define a structure to hold bid information
struct Bid {
    string bidId; // unique identifier
    string dept;
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

// FIXME (1): Internal structure for tree node
// holds bid data and left and right pointers
struct Node {
	Bid data;
	Node* left;
	Node* right;
};


//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class BinarySearchTree {

private:
    Node* root;// root pointer

    void addNode(Node* node, Bid bid);
    void inOrder(Node* node);
    void inOrderDelete(Node* node);
    Node* removeNode(Node* node, string bidId);
    int size;


public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    void Insert(Bid bid);
    void Remove(string bidId);
    Bid Search(string bidId);
    int Size();

};

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
    // initialize housekeeping variables
	root = NULL;
	size = 0;

}

/**
 * Destructor
 */
BinarySearchTree::~BinarySearchTree() {
    // recurse from root deleting every node
	inOrderDelete(root);

}

void BinarySearchTree::inOrderDelete(Node* node){
	if (node == NULL){
			return;
		}
		inOrder(node->left);
		delete (node);
		inOrder(node->right);
}

/**
 * Traverse the tree in order
 */
void BinarySearchTree::InOrder() {
	inOrder(root);
}
/**
 * Insert a bid
 */
void BinarySearchTree::Insert(Bid bid) {
    // FIXME (2a) Implement inserting a bid into the tree
	if (root == NULL){ //checks for empty root, and adds node to root if empty
		root = new Node;
		root->data = bid;
		root->left = NULL;
		root->right = NULL;
		++size;
	}
	else{
		addNode(root, bid);//calls addNode to add nodes to tree
	}
}

/**
 * Remove a bid
 */
void BinarySearchTree::Remove(string bidId) {
    // FIXME (4a) Implement removing a bid from the tree
	Node* currNode = new Node;
	Node* parNode = new Node;

	currNode = root;//current node starts at root
	parNode = NULL;//variable used to track parent node

	while (currNode != NULL){
		if (currNode->data.bidId == bidId){
			if (currNode->left == NULL && currNode->right == NULL){//removes leaf
				if (parNode == NULL){
					root = NULL;//removes root with no pointers
				}
				else if (parNode->left == currNode){
					parNode->left = NULL;
				}
				else{
					parNode->right = NULL;
				}
			}
			else if (currNode->left != NULL && currNode->right == NULL){//removes node with only left branch
				if (parNode == NULL){
					root = currNode->left;
				}
				else if (parNode->left == currNode){
					parNode->left = currNode->left;
				}
				else{
					parNode->right = currNode->left;
				}
			}
			else if (currNode->left == NULL && currNode->right != NULL){//removes node with only right branch
				if (parNode == NULL){
					root = currNode->right;
				}
				else if (parNode->left == currNode){
					parNode->left = currNode->right;
				}
				else{
					parNode->right = currNode->right;
				}
			}
			else{//removes node with left and right branch
				Node* sucNode = new Node;
				Node* sucParNode = new Node;
				sucNode = currNode->right;
				sucParNode = currNode;
				while (sucNode->left != NULL){
					sucParNode = sucNode;
					sucNode = sucNode->left;
				}
				currNode->data = sucNode->data;
				sucParNode->left = NULL;
			}
			return;
		}
		else if (currNode->data.bidId < bidId){
			parNode = currNode;
			currNode = currNode->right;
		}
		else{
			parNode = currNode;
			currNode = currNode->left;
		}
	}
	return;
}

/**
 * Search for a bid
 */
Bid BinarySearchTree::Search(string bidId) {
    // FIXME (3) Implement searching the tree for a bid
	Bid bid;
	Node* currNode = new Node;
	currNode = root;

	while (currNode != NULL){
		if (bidId == currNode->data.bidId){//bid found
			bid = currNode->data;
			return bid;
		}
		else if (bidId < currNode->data.bidId){//search to left
			currNode = currNode->left;
		}
		else{
			currNode = currNode->right;//search to right
		}
	}
    return bid;
}


/**
 * Add a bid to some node (recursive)
 *
 * @param node Current node in tree
 * @param bid Bid to be added
 */
void BinarySearchTree::addNode(Node* node, Bid bid) {
    // FIXME (2b) Implement inserting a bid into the tree

	if (bid.bidId < node->data.bidId){
		if (node->left == NULL){//adds node to left
			node->left = new Node;
			node->left->data = bid;
			node->left->left = NULL;
			node->left->right= NULL;
			++size;
		}
		else{
			addNode(node->left, bid);
		}
	}
	else{
		if (node->right == NULL){//adds node to right
			node->right = new Node;
			node->right->data = bid;
			node->right->left = NULL;
			node->right->right= NULL;
			++size;
		}
		else{
			addNode(node->right, bid);
		}
	}
}
void BinarySearchTree::inOrder(Node* node) {

	if (node == NULL){
			return;//move back up tree
	}
	inOrder(node->left);//iterate to left most node
	cout << node->data.bidId << ": " << node-> data.dept << " | " << node->data.title << " | " << node->data.amount << " | "//print current node
			<< node->data.fund << endl;

	inOrder(node->right);//iterate to right most node

}

int BinarySearchTree::Size(){
	return size;//returns size of tree
}
//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the bid information to the console (std::out)
 *
 * @param bid struct containing the bid info
 */
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.dept << " | " << bid.title << " | " << bid.amount << " | "
            << bid.fund << endl;
    return;
}

/**
 * Load a CSV file containing bids into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the bids read
 */
void binaryLoadBids(string csvPath, BinarySearchTree* bst) {
    cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);


    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of bids
            Bid bid;
            bid.bidId = file[i][1];
            bid.dept = file[i][2];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            //insert bid into binary tree
            bst->Insert(bid);
        }
    } catch (csv::Error &e) {
        std::cerr << e.what() << std::endl;
    }
}

vector<Bid> vectorLoadBids(string csvPath) {

    // Define a vector data structure to hold a collection of bids.
    vector<Bid> bids;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    try {
        // loop to read rows of a CSV file
        for (int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of bids
            Bid bid;
            bid.bidId = file[i][1];
            bid.dept = file[i][2];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            // push this bid to the end of the vector
            bids.push_back(bid);
        }
    } catch (csv::Error &e) {
        std::cerr << e.what() << std::endl;
    }
    return bids;
}

int partition(vector<Bid>& bids, int begin, int end) {
	int i = 0;
	int j = 0;
	int midpoint = 0;
	string pivot = "";
	string temp = "";
	bool done = false;

	   // creates a pivot at the midpoint of the vector
	midpoint = begin + (end - begin) / 2;
	pivot = bids.at(midpoint).dept;

	i = begin;
	j = end;

	//loop partitions by comparing titles to the pivot, using i, j and temp to move the titles
	while (!done) {


		while (bids.at(i).dept < pivot) {
			++i;
	    }


	    while (pivot < bids.at(j).dept) {
	    	--j;
	    }

	    //makese sure there are still elements to partition
	    if (i >= j) {
	    	done = true;
	    }
	    else {

	    	temp = bids.at(i).dept;
	        bids.at(i).dept = bids.at(j).dept;
	        bids.at(j).dept = temp;

	        ++i;
	        --j;
	     }
	}
	return j;
}

void quickSort(vector<Bid>& bids, int begin, int end) {
	int j = 0;

	   //makes sure there are still elements to sort
	   if (begin >= end) {
	      return;
	   }

	   //calls partition function
	   j = partition(bids, begin, end);

	   //recursively sorts low half and high half of partition by repartitioning
	   //each half until all elements are sorted
	   quickSort(bids, begin, j);
	   quickSort(bids, j + 1, end);

	   return;

}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath, bidKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        bidKey = "98109";
        break;
    case 3:
        csvPath = argv[1];
        bidKey = argv[2];
        break;
    default:
        csvPath = "src//eBid_Monthly_Sales.csv";
        bidKey = "98109";
    }

    // Define a binary search tree to hold all bids
    BinarySearchTree* bst;

    // Define a vector to hold all the bids
    vector<Bid> bids;

    Bid bid;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids By ID" << endl;
        cout << "  3. Display All Bids By Department" << endl;
        cout << "  4. Find Bid by Bid ID" << endl;
        cout << "  5. Find Bids by Department" << endl;
        cout << "  6. Remove Bid by Bid ID" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            bst = new BinarySearchTree();

            // Complete the method call to load the bids
            binaryLoadBids(csvPath, bst);
            bids = vectorLoadBids(csvPath);
            quickSort(bids, 0, bids.size() - 1);

            cout << bst->Size() << " bids read" << endl;

            break;

        case 2:
            bst->InOrder();
            break;

        case 3:
        	// Loop and display the bids read
        	for (int i = 0; i < bids.size(); ++i) {
        		displayBid(bids[i]);
        	}
        	cout << endl;
        	break;

        case 4:

            cout << "Enter a Bid ID: ";
            cin >> bidKey;

            //search for bid by entered ID
            bid = bst->Search(bidKey);

            if (!bid.bidId.empty()) {
                displayBid(bid);
            } else {
            	cout << "Bid Id " << bidKey << " not found." << endl;
            }

            break;

        case 5:

        	cout << "Enter a Department: ";
        	cin >> bidDept;

        	//search vector for any bids with entered department
        	for (int i = 0; i < bids.size(); ++i) {
        		bid = bids[i];
        		if (bid.dept == bidDept){
        			displayBid(bid);
        		}
        	}
        	break;

        case 6:
        	cout << "Enter a Bid ID: ";
        	cin >> bidKey;

            bst->Remove(bidKey);
            break;
        }
    }

    cout << "Good bye." << endl;

	return 0;
}
